const _ = require("lodash");
const User = require("../models/user");

exports.userById = (req, res, next, id) => {
  User.findById(id)
    // populate followers and following users array

    .exec((err, user) => {
      if (err || !user) {
        return res.status(400).json({
          error: "User not found",
        });
      }
      req.profile = user; // adds profile object in req with user info
      next();
    });
};

exports.adduser = async (req, res) => {
  try {
    const userExists = await User.findOne({ username: req.body.username });
    if (userExists)
      return res.status(403).json({
        error: "username is already taken!",
      });
    const user = await new User(req.body);
    await user.save();
    res.status(200).json({ message: "user added successfully" });
  } catch (e) {
    res.status(500).json(e);
  }
};

exports.getUser = (req, res) => {
  return res.json(req.profile);
};

exports.updateUser = async (req, res, next) => {
  try {
    let id = req.params.userId;

    console.log(id, req.body);

    let ud = await User.findByIdAndUpdate(id, req.body);

    res.status(200).json(ud);
  } catch (e) {
    res.status(500).json(e);
  }
};

exports.allUsers = async (req, res) => {
  console.log(req.params.page);

  const currentPage = req.params.page || 1;
  const ppg = req.body.limit || 5;

  const perPage = parseInt(ppg);
  let totalItems;

  const posts = await User.find()

    .countDocuments()
    .then((count) => {
      totalItems = count;
      return User.find()
        .skip((currentPage - 1) * perPage)

        .limit(perPage)
        .sort({ createdAt: -1 });
    })
    .then((posts) => {
      res.status(200).json(posts);
    })
    .catch((err) => console.log(err));
};

exports.deleteUser = async (req, res, next) => {
  try {
    let id = req.params.userId;

    let ud = await User.findByIdAndUpdate(id, { isActive: "false" });

    res.status(200).json(ud);
  } catch (e) {
    res.status(500).json(e);
  }
};
