const express = require("express");
const {
  userById,
  adduser,
  allUsers,
  getUser,
  updateUser,
  deleteUser,
} = require("../controllers/user");

const router = express.Router();
router.post("/adduser", adduser);

router.get("/users/:page", allUsers);
router.get("/user/:userId", getUser);
router.put("/user/:userId", updateUser);
router.delete("/user/:userId", deleteUser);

// any route containing :userId, our app will first execute userByID()
router.param("userId", userById);

module.exports = router;
