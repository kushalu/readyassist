import React from "react";
import { Route, Switch } from "react-router-dom";

import Edituser from "./components/Edituser";
import Users from "./components/Users";
const MainRouter = () => (
  <div>
    <Switch>
      <Route exact path="/" component={Users} />
      <Route exact path="/user/:userId" component={Edituser} />
    </Switch>
  </div>
);

export default MainRouter;
