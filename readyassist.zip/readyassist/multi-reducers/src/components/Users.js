import React, { Component } from "react";

import { list, deleteUser } from "./api";

import { connect } from "react-redux";
import Adduser from "./Adduser";
// import Edituser from "./Edituser";
import { Link } from "react-router-dom";

import { users } from "../store/actions/actions";
class Users extends Component {
  constructor(props) {
    super(props);
    this.state = {
      page: 1,
      error: " ",
      userid: "",
      username: "",
      firstname: "",
      lastname: "",
      success: "",
    };
  }
  handleChange = (search) => (event) => {
    this.setState({ error: "" });
    this.setState({ [search]: event.target.value });
  };
  clickSubmit = (event) => {
    this.props.search(this.state.search);
  };

  componentDidMount() {
    var page = this.state.page;
    list({ page }).then((data) => {
      if (data.error) {
      } else {
        //this.setState({ users: data });
        //  console.log(data);
        this.props.users(data);
      }
    });
  }
  componentWillReceiveProps(props) {
    var page = this.state.page;
    list({ page }).then((data) => {
      if (data.error) {
      } else {
        //this.setState({ users: data });
        //  console.log(data);
        this.props.users(data);
      }
    });
  }
  delete(val) {
    console.log(val);
    deleteUser(val).then((data) => {
      if (data.error) {
      } else {
        this.setState({ success: "deleted successfully" });
      }
    });
  }

  loadMore = (number) => {
    this.setState({ page: this.state.page + number });
    var page = this.state.page;
    list({ page }).then((data) => {
      if (data.error) {
      } else {
        //this.setState({ users: data });
        //  console.log(data);
        this.props.users(data);
      }
    });
  };

  loadLess = (number) => {
    this.setState({ page: this.state.page - number });
    var page = this.state.page;
    list({ page }).then((data) => {
      if (data.error) {
      } else {
        //this.setState({ users: data });
        //  console.log(data);
        this.props.users(data);
      }
    });
  };
  render() {
    return (
      <div className="container ml-5 mt-5">
        <button
          type="button"
          class="btn btn-primary"
          data-toggle="modal"
          data-target="#exampleModal"
        >
          Add User
        </button>

        <div
          className="modal fade"
          id="exampleModal"
          tabindex="-1"
          role="dialog"
          aria-labelledby="exampleModalLabel"
          aria-hidden="true"
        >
          <button
            type="button"
            class="close"
            data-dismiss="modal"
            aria-label="Close"
          ></button>
          <div className="modal-dialog" role="document">
            <Adduser />
          </div>
        </div>
        <div class="modal fade" id="myModal2" role="dialog">
          <div class="modal-dialog"></div>
        </div>
        <table className="table">
          <thead>
            <tr>
              <th>User Name</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Is Active</th>
              <th>Edit </th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {this.props.us.map((user, i) => (
              <tr>
                <td>{user.username}</td>
                <td>{user.firstname}</td>
                <td>{user.lastname}</td>
                <td>{user.isActive.toString()}</td>
                <td>
                  <Link
                    to={`/user/${user._id}`}
                    className="btn btn-raised btn-danger btn-sm"
                  >
                    Edit
                  </Link>
                </td>

                <td>
                  <button
                    className="btn btn-raised btn-success btn-sm"
                    onClick={() => this.delete(user._id)}
                  >
                    delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="container">
          <h2 className="mt-5 mb-5">
            {!this.props.us.length ? "No more posts!" : "Recent Posts"}
          </h2>

          {/* {this.renderPosts(this.props.us)} */}

          {this.state.page > 1 ? (
            <button
              className="btn btn-raised btn-warning mr-5 mt-5 mb-5"
              onClick={() => this.loadLess(1)}
            >
              Previous ({this.state.page - 1})
            </button>
          ) : (
            ""
          )}

          {this.props.us.length ? (
            <button
              className="btn btn-raised btn-success mt-5 mb-5"
              onClick={() => this.loadMore(1)}
            >
              Next ({this.state.page + 1})
            </button>
          ) : (
            ""
          )}
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    us: state.users.users,
  };
};

export default connect(
  mapStateToProps, // mapDispachToProps,
  {
    users,
  }
)(Users);
