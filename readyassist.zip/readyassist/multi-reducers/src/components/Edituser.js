import React, { Component } from "react";

import { user, editUser } from "./api";
class Edituser extends Component {
  constructor(props) {
    super();
    this.state = {
      username: "",
      firstname: "",
      lastname: "",
      userid: "",
      loading: false,
      error: "",
      success: "",
      user: {},
    };
  }

  componentDidMount() {
    const userId = this.props.match.params.userId;
    user({ userId }).then((data) => {
      if (data.error) {
      } else {
        this.setState({
          username: data.username,
          firstname: data.firstname,
          lastname: data.lastname,
        });
      }
    });
  }

  isValid = () => {
    const { username, firstname } = this.state;

    if (username.length === 0 || firstname.length === 0) {
      this.setState({ error: "All fields are required", loading: false });
      return false;
    }
    return true;
  };
  handleChange = (username) => (event) => {
    this.setState({ error: "" }); //-> when user inserting a input after getting error it will vanish by itself
    this.setState({ [username]: event.target.value });
  };
  clickSubmit = (event) => {
    event.preventDefault();
    this.setState({ loading: true });

    const { username, firstname, lastname } = this.state;
    // now to create object and send it to the backend

    const user = {
      username,
      firstname,
      lastname,
    };

    if (this.isValid()) {
      const userId = this.props.match.params.userId;
      editUser(user, userId).then((data) => {
        console.log(data.error);
        if (data.error) this.setState({ error: data.error });
        else {
          this.setState({
            loading: false,
            success: "successfully updated auser",
            username: "",
            firstname: "",
            lastname: "",
          });
        }
      });
    }
  };

  newPostForm = (username, firstname, lastname) => (
    <form>
      <div className="form-group">
        {this.props.userid}
        <label className="text-muted">User Name</label>
        <input
          onChange={this.handleChange("username")}
          type="text"
          className="form-control"
          value={username}
        />
      </div>

      <div className="form-group">
        <label className="text-muted">First Name</label>
        <textarea
          onChange={this.handleChange("firstname")}
          type="text"
          className="form-control"
          value={firstname}
        />
      </div>
      <div className="form-group">
        <label className="text-muted">Last Name</label>
        <textarea
          onChange={this.handleChange("lastname")}
          type="text"
          className="form-control"
          value={lastname}
        />
      </div>
      <button onClick={this.clickSubmit} className="btn btn-raised btn-primary">
        Edit user
      </button>
    </form>
  );

  render() {
    const {
      username,
      firstname,

      lastname,
      error,
      loading,
      success,
    } = this.state;

    return (
      <div className="container mr-3" style={{ width: "50%" }}>
        <h2 className="mt-5 mb-5">Edit user</h2>
        <div
          className="alert alert-success"
          style={{ display: success ? "" : "none" }}
        >
          {success}
        </div>
        <div
          className="alert alert-danger"
          style={{ display: error ? "" : "none" }}
        >
          {error}
        </div>

        {loading ? (
          <div className="jumbotron text-center">
            <h2>Loading...</h2>
          </div>
        ) : (
          ""
        )}

        {this.newPostForm(username, firstname, lastname)}
      </div>
    );
  }
}
export default Edituser;
