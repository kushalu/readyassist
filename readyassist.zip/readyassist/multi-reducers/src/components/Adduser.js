import React, { Component } from "react";

import { addUser } from "./api";

class AddUser extends Component {
  constructor() {
    super();
    this.state = {
      username: "",
      firstname: "",
      lastname: "",
      loading: false,
      error: "",
      success: "",
      user: {},
    };
  }

  isValid = () => {
    const { username, firstname } = this.state;

    if (username.length === 0 || firstname.length === 0) {
      this.setState({ error: "All fields are required", loading: false });
      return false;
    }
    return true;
  };
  handleChange = (username) => (event) => {
    this.setState({ error: "", success: "" }); //-> when user inserting a input after getting error it will vanish by itself
    this.setState({ [username]: event.target.value });
  };
  clickSubmit = (event) => {
    event.preventDefault();
    this.setState({ loading: true });

    const { username, firstname, lastname } = this.state;
    // now to create object and send it to the backend

    const user = {
      username,
      firstname,
      lastname,
    };

    if (this.isValid()) {
      addUser(user).then((data) => {
        console.log(data.error);
        if (data.error) this.setState({ error: data.error });
        else {
          this.setState({
            loading: false,
            success: "successfully added  a user",
            username: "",
            firstname: "",
            lastname: "",
          });
        }
      });
    }
  };

  newPostForm = (username, firstname, lastname) => (
    <form>
      <div className="form-group">
        <label className="text-muted">User Name</label>
        <input
          onChange={this.handleChange("username")}
          type="text"
          className="form-control"
          placeholder="user name"
          value={username}
        />
      </div>

      <div className="form-group">
        <label className="text-muted">First Name</label>
        <textarea
          onChange={this.handleChange("firstname")}
          type="text"
          className="form-control"
          placeholder="first name"
          value={firstname}
        />
      </div>
      <div className="form-group">
        <label className="text-muted">Last Name</label>
        <textarea
          onChange={this.handleChange("lastname")}
          type="text"
          className="form-control"
          placeholder="last name"
          value={lastname}
        />
      </div>
      <button onClick={this.clickSubmit} className="btn btn-raised btn-primary">
        Add user
      </button>
    </form>
  );

  render() {
    const {
      username,
      firstname,

      lastname,
      error,
      loading,
      success,
    } = this.state;

    return (
      <div className="container mr-3" style={{ width: "50%" }}>
        <h2 className=" text-primary mt-5 mb-5">Add new user</h2>
        <div
          className="alert alert-success"
          style={{ display: success ? "" : "none" }}
        >
          {success}
        </div>
        <div
          className="alert alert-danger"
          style={{ display: error ? "" : "none" }}
        >
          {error}
        </div>

        {loading ? (
          <div className="jumbotron text-center">
            <h2>Loading...</h2>
          </div>
        ) : (
          ""
        )}

        {this.newPostForm(username, firstname, lastname)}
      </div>
    );
  }
}

export default AddUser;
