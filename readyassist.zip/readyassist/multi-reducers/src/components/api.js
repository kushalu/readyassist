export const addUser = (user) => {
  return fetch(`http://localhost:8080/adduser`, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify(user),
  })
    .then((response) => {
      return response.json();
    })
    .catch((err) => console.log(err));
};
export const editUser = (user, userid) => {
  console.log(user, userid);
  return fetch(`http://localhost:8080/user/${userid}`, {
    method: "PUT",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify(user),
  })
    .then((response) => {
      return response.json();
    })
    .catch((err) => console.log(err));
};
//delete
export const deleteUser = (userid) => {
  return fetch(`http://localhost:8080/user/${userid}`, {
    method: "DELETE",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify(user),
  })
    .then((response) => {
      return response.json();
    })
    .catch((err) => console.log(err));
};
export const list = ({ page }) => {
  return fetch(`http://localhost:8080/users/${page}`, {
    method: "GET",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      // Authorization: `Bearer ${token}`, //${isAuthenticated().token}` -> istead of thiis
    },
  })
    .then((response) => {
      // its a promise based so need to promise here before
      return response.json();
    })
    .catch((err) => console.log(err));
};
//user
export const user = (userid) => {
  console.log(userid);
  return fetch(`http://localhost:8080/user/${userid}`, {
    method: "GET",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
  })
    .then((response) => {
      return response.json();
    })
    .catch((err) => console.log(err));
};
