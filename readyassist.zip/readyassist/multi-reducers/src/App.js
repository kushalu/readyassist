import React /*, { Component }*/ from "react";
import { BrowserRouter } from "react-router-dom";
//import Task from "./components/Task";

import MainRouter from "./MainRouter";

const App = () => (
  <BrowserRouter>
    <MainRouter />
  </BrowserRouter>
  // <Task />
);

export default App;
