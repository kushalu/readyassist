//users
export const users = (val) => {
  return { type: "USERS", value: val };
};
