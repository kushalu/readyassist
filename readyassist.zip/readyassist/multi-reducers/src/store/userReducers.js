const initialState = {
  users: [],
};

const reducer = (state = initialState, action) => {
  if (action.type === "USERS") {
    return {
      ...state,
      users: action.value,
    };
  }

  return state;
};
export default reducer;
